// components/w-star-top/w-star-top.js
var app = getApp()
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    herb: {
      type: Object,

      observer: function (newVal, oldVal) {
        console.log(newVal, oldVal)
      }
    }
    
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    onShareAppMessage: function (res) {
      return {
        title: '中药溯源系统',
        path: '/pages/index/index',

      }
    },
	  addHerb(e){
      
      console.log(this.properties.herb)
      console.log("点击事件")
	    console.log(e)
	  
	    const item = e.currentTarget.dataset.item
      console.log(typeof(item))
     
	    // console.log(app.globalData.carts)
	    const i = app.globalData.carts.findIndex(v=>v._id == item._id)
	    // const i = app.globalData.carts.findIndex(function (value, index, arr) {
	    //   return value == item._id;
	    // })
	    if(i>-1){
	      console.log('收藏过了') 
	      wx.showToast({
	        title:'您已收藏过啦'
	      }) 
	    }
	    else{
	      app.globalData.carts.push(item)
	      wx.showToast({
	        title: '收藏成功'
	      }) 
	    }
      wx.setStorageSync('carts',app.globalData.carts)
	  }

  }
})

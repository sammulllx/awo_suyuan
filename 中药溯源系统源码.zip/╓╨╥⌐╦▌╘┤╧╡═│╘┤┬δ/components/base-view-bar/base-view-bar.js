// components/base-view-bar/base-view-bar.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
		bases: {
		  type: Array,
		  observer: function (newVal, oldVal) {
		    console.log(newVal, oldVal)
		  }
		}
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
	  gotobase: function () {
	    let plugin = requirePlugin('routePlan');
	    let key = 'YWTBZ-NZW6P-6PWDI-L562P-YLCJO-3OFXH';  //使用在腾讯位置服务申请的key
	    let referer = 'sammul';   //调用插件的app的名称
	    let endPoint = JSON.stringify({  //终点
	      'name': '茂名化橘红基地',
	      'latitude': 21.67,
	      'longitude': 110.63
	    });
	    wx.navigateTo({
	      url: 'plugin://routePlan/index?key=' + key + '&referer=' + referer + '&endPoint=' + endPoint
	    });
	  
	  },

  }
})

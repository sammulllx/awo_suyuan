
var app = getApp();
var all_imgsrc = app.globalData.all_imgsrc;

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // title:String
    herbs: {
      type: Array,
      observer: function (newVal, oldVal) {
        console.log(newVal, oldVal)
      }
    }
  },
  externalClasses: ['titleclass'],

  /**
   * 组件的初始数据
   */
  data: {
    img_src: all_imgsrc,
  },
  options: {
    // styleIsolation: "shared"

  },
  /**
   * 组件的方法列表
   */
  methods: {

  },
  pageLifetimes: {
    attached: function () {
      console.log("展示")
    },
}
})

//app.js


App({

  onLaunch: function () {
    wx.cloud.init()
	const userInfo = wx.getStorageSync('userInfo')
	if(userInfo){
		this.globalData.userInfo = userInfo
		
	}
	
    //调用API从本地缓存中获取数据
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
  },

  globalData:{
  userInfo:null,
 
  carts:wx.getStorageSync('carts') || [],
  his_carts:wx.getStorageSync('his_carts') || [],
	all_imgsrc:"http://image.zysuyuan.cn:8031/",
	all_src:"http://api.zysuyuan.cn:8031/",
	// all_imgsrc:"http://192.168.1.109:8031/",
	// all_src:"http://192.168.1.109:10008/",
  },
 
 
})
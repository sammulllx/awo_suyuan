var app = getApp()
Page({
  data: {
    dataBar: [
      {
        imageUrl: "/image/star-logo.png",
        text: "我的收藏",
        url: "../collect/collect"
      },
      {
        imageUrl: "/image/3d-glasses.png",
        text: "浏览记录",
        url: "../history/history"
      },
      {
        imageUrl: "/image/book.png",
        text: "帮助",
        url: "../help/help"
      }
      // {
      //   imageUrl: "/image/laptop.png",
      //   text: "扫一扫查询",
      //   url: "../blank/blank"
      // }
    ]
  },
  onShareAppMessage: function(res) {
      return {
        title:'中药溯源系统',
        path: '/pages/index/index',
  
        }
  	},
	onLoad(){
		if(app.globalData.userInfo){
			this.setData({
				userInfo : app.globalData.userInfo,
				hasUserInfo:true
			})
		}
		else if(this.data.canIUse){
			app.userInfoReadyCallback= res=> {
				this.setData({
					userInfo:res.userInfo,
					hasUserInfo:true
				})
			}
		} 
		else{
			wx.getUserInfo({
				sucess:res => {
					app.globalData.userInfo = res.userInfo
					this.setData({
						userInfo:res.userInfo,
						hasUserInfo:true
					})
				}
			})
		}
	},
  getUserInfo(e){
  	console.log("点了")
    wx.cloud.callFunction({
     name:'login',
     data:{
       a:10,
       b:20
     },success:res=>{
       e.detail.userInfo.openid = res.result.openid
       app.globalData.userInfo = e.detail.userInfo
       this.setData({
         userInfo: e.detail.userInfo,
         
       }, res => { console.log("成功") })
       wx.setStorageSync('userInfo',e.detail.userInfo)
  
     }
  
    })
  
  
  }
})
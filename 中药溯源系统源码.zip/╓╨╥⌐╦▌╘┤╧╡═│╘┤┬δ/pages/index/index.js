//index.js
//获取应用实例
var app =getApp();
var all_imgsrc = app.globalData.all_imgsrc;
var all_src = app.globalData.all_src;
var API_URL = all_src+'api/item/medicinalInf/list/views';

const db = wx.cloud.database()
const TOP_DISTANCE = 100;




Page({
  data: {
	img_src:all_imgsrc,
	showBackTop:false,
	herbs:[],
	title:"加载中",
    grids: [0, 1, 2, 3, 4, 5, 6, 7, 8], 
  },
  touchHerb(e) {
    console.log("触发touch事件")
    console.log(e)
    const item = e.currentTarget.dataset.item
    console.log(typeof (item))
    const i = app.globalData.his_carts.findIndex(v => v._id == item._id)
 
    if (i > -1) {
     
    }
    else {
      app.globalData.his_carts.push(item)
     
    }
    wx.setStorageSync('his_carts', app.globalData.his_carts)
  },
  onShareAppMessage: function(res) {
      return {
        title:'中药溯源系统',
        path: '/pages/index/index', 
        }
  	},
 onPullDownRefresh() {
	 wx.setBackgroundColor({
	   backgroundColor: '#ffffff', // 窗口的背景色为白色
	    backgroundColorBottom: '#ffffff', // 底部窗口的背景色为白色
	 });

	  this.updateBlogs();
	  console.log("正在下拉刷新");
	  wx.showToast({
	    title: '刷新成功',
	    icon: 'success',
	    duration: 5000
	  })
	},
	  
  
updateBlogs : function () {
    var that = this;
    wx.request({
    	url:API_URL,
    	data:{},
    	header:{
        'Content-Type': 'json'
    	},
    	success:function (res){
         console.log(res.data[0]);
    		wx.hideToast();
    		var data = res.data;
    		that.setData({			
    			herbs:data
    		});
    	}
    });
	console.log("刷新成功")
  },

//搜素时触发，调用search: function (key)，传入输入的e.detail.value值
wxSearchInput: function (e) {
 // this.search(e.detail.value);
 console.log("sss")
 console.log(e)
 console.log(e["detail"]["value"])
 console.log(e["detail"].value);
},
wxSearchFn:function(e){
	console.log("aaa")
	console.log(e)
},
controltap() {
    // 二维码控件处理
      wx.scanCode({
        success: (res) => {
			console.log("扫码结果");
			  console.log(typeof(res.result));      			 
			   wx.navigateTo({
			   url:res.result,
			  }
			   )
			   }
         ,
        fail: (res) => {    
			console.log('scan    qrcode    fail')
        }
      })
  },
  onPageScroll(options){
	  // console.log(options)
	  const scrollTop = options.scrollTop;
	  const flag = scrollTop >= TOP_DISTANCE;
	  if(flag != this.data.showBackTop){
	  this.setData({
	  		  showBackTop:scrollTop >= TOP_DISTANCE
		})
		
	}
	  
  },
  onLoad:function (e){
	  
	  console.log('onload')
  	var that = this;
	
  	wx.showToast({
  		title:"加载中...",
  		icon:"loading",
  		duration:10000
  	});
    db.collection('drug').get({
      success: res => {
        console.log(res.data)
        this.setData({
          herbs: res.data
        })
        wx.hideToast()
      }
    })

  
	console.log("dd")
	wx.getUserInfo({
		sucess:res => {
			app.globalData.userInfo = res.userInfo
			this.setData({
				userInfo:res.userInfo,
				hasUserInfo:true
			})
		}
	})

	
	 
	
	
  },
  onShow:function(){
    console.log('onShow')
    db.collection('drug').get({
      success: res => {
        console.log(res.data)
        this.setData({
          herbs: res.data
        })
        wx.hideToast()
      }
    })
  }
})


const db = wx.cloud.database()
var app = getApp()

console.log("加载到哦")
Page({

  /**
   * 页面的初始数据
   */
  data: {
    history:[],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      history: app.globalData.his_carts
    })
    var herbs = []

    for (var i = 0; i < this.data.history.length; i++) {

      db.collection('drug').doc(this.data.history[i]._id).get({
        success: (res) => {

          herbs.push(res.data)
          this.setData({
            herb: herbs
          })
          this.setData({
            oldherb: herbs
          })

          // console.log(res.data)
          console.log('????????????????????????')

          console.log('????????????????????????')

        }
      })
    }

    
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log("onShow")
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
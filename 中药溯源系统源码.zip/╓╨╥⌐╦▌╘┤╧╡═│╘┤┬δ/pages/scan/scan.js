var app = getApp()
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {
	
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
	  db.collection('drug').get({
	  	success:res=>{
	  		console.log(res.data)
			this.setData({
				herbs:res.data
			})
			
			
	  		
	  	}
	  })
		if(app.globalData.userInfo){
			console.log("从globaldata")
			this.setData({
				userInfo : app.globalData.userInfo,
				hasUserInfo:true
			})
		}
		else if(this.data.canIUse){
			console.log("ddd")
			app.userInfoReadyCallback= res=> {
				this.setData({
					userInfo:res.userInfo,
					hasUserInfo:true
				})
			}
		} 
		else {
			
			wx.getUserInfo({
				
				sucess:res => {
					console.log("wx.getUserInfo");
					app.globalData.userInfo = res.userInfo
					this.setData({
						userInfo:res.userInfo,
						hasUserInfo:true
					})
					
				},
				fail : res=>{console.log("wx.getUserInfo失败")}
			})
		}
		
},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  
getUserInfo(e){
	
  wx.cloud.callFunction({
   name:'login',
   data:{
     a:10,
     b:20
   },success:res=>{
     e.detail.userInfo.openid = res.result.openid
     app.globalData.userInfo = e.detail.userInfo
     this.setData({
       userInfo: e.detail.userInfo,
       
     }, res => { console.log("成功") })
     wx.setStorageSync('userInfo',e.detail.userInfo)

   }

  })

 },
 getMall(){
	 console.log("dsdfas")
	 db.collection('emall').get({
		success:res=>{
			console.log(res)
			
		}
	})
 },
 addMall(){
	 
	 wx.chooseImage({
		 count:1,
		 success:function(res){
			 const filePath = res.tempFilePaths[0]
			 const tempFile = filePath.split('.')
			 console.log(filePath)
			 console.log(tempFile)
			 console.log(tempFile.length)
			 console.log(tempFile.length[-2])
			 
			 const cloudPath = 'panda-image-' + tempFile[tempFile.length-2]
			 wx.cloud.uploadFile({
				 cloudPath,
				 filePath,
				 success:res=>{
				 console.log(res)
				 db.collection('emall').add({
				 		 data:{
							title:'商品2',
							price:18,
							tags:['books','food'],
							img:res.fileID
				 		 },
				 		 success:ret=>{
				 			 console.log(ret)
				 			 wx.showToast({
				 				 title:'添加成功'
				 			 })
				 		 }
				   })
				 }
			 })
			
		 },
	 })
	 
	
 }
})
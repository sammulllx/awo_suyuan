// pages/collect/collect.js
var app = getApp()

const db = wx.cloud.database()

Page({
 

  /**
   * 页面的初始数据
   */
  data: {
    drug:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var a = [];
    console.log('a')
    console.log(a)
    console.log(a.length)
    console.log('a')
    console.log(app.globalData.carts)
    this.setData({
      drug:app.globalData.carts
    })
    console.log(this.data.drug)
    console.log(this.data.drug[0])
    console.log(this.data.drug[3])
    console.log(Object.keys(this.data.drug).length)
    console.log(typeof(this.data.drug))
    
    var herbs = []

    for (var i = 0; i < this.data.drug.length; i++) {

      db.collection('drug').doc(this.data.drug[i]._id).get({
        success: (res) => {

          herbs.push(res.data)
          this.setData({
            herb: herbs
          })
          this.setData({
            oldherb: herbs
          })

          // console.log(res.data)
          console.log('????????????????????????')

          console.log('????????????????????????')

        }
      })
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      drug: app.globalData.carts
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  

})